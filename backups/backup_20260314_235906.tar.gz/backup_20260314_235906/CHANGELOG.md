# 本次备份变更日志

## 📋 配置变更

### openclaw.json 主要变更
- 模型配置：已移除 GPT-5.4，只保留阿里云千问 qwen3.5-plus
- 默认模型：custom-coding-dashscope-aliyuncs-com/qwen3.5-plus

## 📊 记忆系统状态

### 记录统计（截至备份时间）
- 情景记忆 (episodes): 32584 条
- 反思记录：23732 条
- 目标任务：41 条

## 🗓️ 最近备份对比

| 项目 | 本次备份 | 上次备份 | 变化 |
|------|----------|----------|------|
| 情景记忆 | 32584 | - | - |
| 反思记录 | 23732 | - | - |
| 目标任务 | 41 | - | - |

## 📁 本次备份文件清单

### 配置文件
-rw-------@ 1 jo  staff   3.6K  3月 14 23:59 /Users/jo/.openclaw/backup_20260314_235906/openclaw.json

### 工作区文档
total 256
-rw-r--r--  1 jo  staff    11K  3月 14 23:59 AGENTS.md
-rw-r--r--  1 jo  staff    21K  3月 14 23:59 AHAO_BACKUP_20260309.md
-rw-r--r--  1 jo  staff   7.3K  3月 14 23:59 BACKUP_GUIDE.md
-rw-r--r--@ 1 jo  staff   615B  3月 14 23:59 boot.md
-rw-r--r--  1 jo  staff   2.1K  3月 14 23:59 CHANGELOG.md
-rw-r--r--  1 jo  staff   3.6K  3月 14 23:59 CHECKLIST.md
-rw-------  1 jo  staff   1.4K  3月 14 23:59 FEISHU-CRON-TIPS.md
-rw-------  1 jo  staff   4.0K  3月 14 23:59 HEART.md
-rw-r--r--  1 jo  staff   152B  3月 14 23:59 HEARTBEAT.md
-rw-r--r--@ 1 jo  staff   1.4K  3月 14 23:59 IDENTITY.md
-rw-r--r--  1 jo  staff   3.5K  3月 14 23:59 RESUME.md
-rw-r--r--  1 jo  staff   1.6K  3月 14 23:59 SOUL.md
-rw-r--r--  1 jo  staff   3.7K  3月 14 23:59 TOOLS.md
-rw-r--r--  1 jo  staff   477B  3月 14 23:59 USER.md
-rw-r--r--  1 jo  staff   3.5K  3月 14 23:59 vectorbrain_speed_test_report.md
-rw-r--r--@ 1 jo  staff   7.5K  3月 14 23:59 阿豪一键复活协议_v3.md
-rw-r--r--@ 1 jo  staff   2.0K  3月 14 23:59 阿豪状态快照.md
-rw-r--r--  1 jo  staff    86B  3月 14 23:59 产品开发 - 落地流程自动化需求信息收集表_待填写.md
-rw-r--r--@ 1 jo  staff    14K  3月 14 23:59 产品开发 - 落地流程自动化需求信息收集表_已填写.md

### 技能列表
- 系统技能：20 个
- 工作区技能：22 个
