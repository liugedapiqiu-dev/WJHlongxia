# OpenClaw 系统备份

**备份时间**: $(date -Iseconds)
**OpenClaw 版本**: $(openclaw --version 2>/dev/null)

## 备份内容

- ✅ openclaw.json (主配置)
- ✅ openclaw.json.bak (配置备份)
- ✅ 工作区文档 (SOUL.md, IDENTITY.md, AGENTS.md 等)
- ✅ VectorBrain 归档状态
- ✅ VectorBrain Connector 脚本
- ✅ 技能清单

## 记忆系统统计

备份时间：2026-03-14T23:59:30+08:00

## 📊 记忆系统统计
- 情景记忆：32584 条
- 知识记忆： 条
- 反思记录：23732 条
- 目标任务：41 条

## 📁 文件列表
total 32
drwxr-xr-x  26 jo  staff   832B  3月 14 23:59 connector_scripts
-rw-------@  1 jo  staff   3.6K  3月 14 23:59 openclaw.json
-rw-------   1 jo  staff   4.2K  3月 14 23:59 openclaw.json.bak
-rw-r--r--   1 jo  staff   565B  3月 14 23:59 README.md
drwxr-xr-x   4 jo  staff   128B  3月 14 23:59 skills
drwxr-xr-x   3 jo  staff    96B  3月 14 23:59 vectorbrain_meta
drwxr-xr-x  21 jo  staff   672B  3月 14 23:59 workspace_docs
